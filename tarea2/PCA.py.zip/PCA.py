import numpy as np
from scipy import linalg as la
import matplotlib.pyplot as plt

#guardar y normalizar los datos
data=np.genfromtxt("siliconwaferthickness.csv",delimiter=",",skip_header=1)
data2=np.zeros(np.shape(data))

for i in range(9):

	data2[:,i]= ( data[:,i] - np.mean(data[:,i]) ) /( np.std(data[:,i]) )


pto1 = data2[:,0]
pto2 = data2[:,1]
pto3 = data2[:,2]
pto4 = data2[:,3]
pto5 = data2[:,4]
pto6 = data2[:,5]
pto7 = data2[:,6]
pto8 = data2[:,7]
pto9 = data2[:,8]

#grafica de los datos
x=np.arange(0,184)
plt.plot(x,pto1,c="red")
plt.plot(x,pto2,c="yellow")
plt.plot(x,pto3,c="blue")
plt.plot(x,pto4,c="black")
plt.plot(x,pto5,c="white")
plt.plot(x,pto6,c="green")
plt.plot(x,pto7,c="gray")
plt.plot(x,pto8,c="orange")
plt.plot(x,pto9,c="brown")
plt.title("Exploracion Datos")
plt.savefig("ExploracionDatos.pdf")
plt.close()




#calcular la matriz de covarianza


def matrizcov(m):
	tam=np.shape(data2)[1]
	matrizc=np.zeros((tam,tam))
	for i in range (0,tam):
		for j in range(0,tam):
				cova=(m[:,i]*m[:,j])
				matrizc[i,j]=np.mean(cova)
	return matrizc

 
matriz_cov = matrizcov(data2)


#autovalores y autovectores
valores_pr,vectores_pr=np.linalg.eig(matriz_cov)

val_prop_in = (np.argsort(valores_pr))


print val_prop_in

#graficar en la nueva base
datos_n = np.dot(vec_prop,data2.T)
plt.scatter(datos_n[7,:],datos_n[8,:])
plt.xlabel("componente principal 1")
plt.ylabel("componente principal 2")
plt.title("PCA datos")
plt.show()
			